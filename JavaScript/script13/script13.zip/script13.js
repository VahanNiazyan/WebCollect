'use strict'


fetch('https://jsonplaceholder.typicode.com/albums',creatAlbums)
    .then(response => response.json())
    .then(json => creatAlbums(json))



function creatAlbums(arr) {
    let albums = document.querySelector('.albums');
    albums.innerHTML = ''

    arr.forEach(elid => {
        let alb = document.createElement('div')
        alb.setAttribute('id', elid.id)
        let title = document.createElement('h3')
        title.innerHTML = elid.title

        alb.appendChild(title)
        albums.appendChild(alb)
        alb.onclick = clickAlb
    })
}

function clickAlb(event) {
    let id = this.getAttribute('id');
        this.style.background = 'darkseagreen';
        let albums = document.querySelectorAll('.albums >div')
        albums.forEach((alb,ind) => {
        alb.style.background = id == ind + 1 ? 'darkseagreen' : 'none'//dsf
        })

        fetch('https://jsonplaceholder.typicode.com/photos?albumId='+id,creatPhotos)
      .then(response => response.json())
      .then(event => creatPhotos(event))
}

function creatPhotos(arr) {
    console.log(arr)
    let photos = document.querySelector('.photos')
    photos.innerHTML = ''
    arr.map(img => {
        let phot = document.createElement('div')
        phot.setAttribute('id', img.id)
        let title = document.createElement('h3')
        title.classList.add('title')
        let im = document.createElement('img')
        let thumbnailUrl = document.createElement('img')
        thumbnailUrl.classList.add('marg')
        thumbnailUrl.setAttribute('src',img.thumbnailUrl)
        im.setAttribute('src', img.url)
        title.innerHTML = img.title


        phot.appendChild(title)
        phot.appendChild(im)
        phot.appendChild(thumbnailUrl)
        photos.appendChild(phot)
    })
}

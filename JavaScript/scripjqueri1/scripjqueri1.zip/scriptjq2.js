'use strict'

$(document).ready(function () {


//    $(window).scroll(function () {
//        let s = $(this).scrollTop()
//        if (s > 350) {
//            $('ul').css({
//                right: 0
//            })
//            $('button').fadeOut(5000)
//        }
//        if (s < 350) {
//            $('ul').css({
//                right: '-100px'
//            })
//        }
//$('li').hover(function () {
////  $('li').animate({
////          background:'red',
////          marginRight:'200px'
////      },4000) 
//    
//      })
        
        
//        $('li').hover(function () {
//             
////            $('.span').css.right = '100px' //({display:'block'})
////            $('.span').css({
////                display: 'block'
////            })
//            $(this).innerText = 'fsdgjskdfksfd fsdioj'
//
//        })

    })





    //==================================================
        $('.button').click(function () {
            $('.modal').fadeIn(1000)
    
            //$('.but').click(function () {
            //    
            //    let inputText = $('#text1')
            //    let spanText = $('#text2')
            //    
            //    console.log("inputText.value" + inputText.value)
            //
            //    if (inputText.value === "") {
            //         spanText.innerText = "Error"
            //    } else {
            //        spanText.innerText = ""
            //    }
            //})
    
    
            let but = document.querySelector('.but')
    
            but.onclick = function () {
                let inputText = document.getElementById('text1')
                let spanText = document.getElementById('text2')
    
                if (inputText.value === '') {
                    spanText.innerText = 'Error Empti'
                } else if (!isNaN(inputText.value)) {
                    spanText.innerText = 'Error Number'
                } else {
                    spanText.innerHTML = ''
                }
    
                let email = document.getElementById('email')
                let emSpan = document.getElementById('emspan')
    
                if (!email.value.includes('@')) {
                    emSpan.innerText = 'Email empti simvol'
                } else {
                    emSpan.innerText = ''
                }
    
    
                let inputPassword = document.getElementById('password')
                let pasSpan = document.getElementById('passpan')
    
                if (inputPassword.value.length < 6) {
                    pasSpan.innerText = 'Length none Error'
                } else if (inputPassword.value.length > 13) {
                    pasSpan.innerText = 'Error big Length'
                } else {
                    pasSpan.innerText = ''
                }
    
                let conPassword = document.getElementById('conpassword')
                let conSpan = document.getElementById('conspan')
    
                if (conPassword.value !== inputPassword.value) {
                    conSpan.innerText = 'Confirm Password mistack'
                } else {
                    conspan.innerText = ''
                }
                
            }
            $('#nan').click(function () {
                $('.modal').css('display', 'none')
            })
        })





// $(window).scroll(function () {
//        let s = $(this).scrollTop()
//        if (s > 350) {
//            $('ul').css({
//                right: 0
//            })
//            $('button').fadeOut(5000)
//        }
//        if (s < 350) {
//            $('ul').css({
//                right: '-100px'
//            })
//        }
//$('li').hover(function () {
//    
//  $('li').animate({
//          background:'red',
//          marginRight:'200px'
//      },4000) 
//    
//      })
//        
//        
////        $('li').hover(function () {
////             
//////            $('.span').css.right = '100px' //({display:'block'})
//////            $('.span').css({
//////                display: 'block'
//////            })
////            $(this).innerText = 'fsdgjskdfksfd fsdioj'
////
////        })
//
//    })


